<?php
session_start();

if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Design-Gweh</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  <link rel="stylesheet" href="josjis.css">
</head>

<body>
  <div class="container-fluid banner">

    <div class="container text-center">
      <h1 style="color: #000000; font-family: arial black; padding: 20px 0;">Design Laboratory
      </h1>
      <h2 style="color: black; font-family: Arial;">Image effect</h2>
      <img style="border: 10px solid rgb(40, 40, 40); border-radius: 10px; margin-top: 20px; margin-bottom: 20px;"
        id="gokil" src="gambar/cukurukuk.png" alt="Gambar Kucing" class="img-fluid">
      <div class="text-center mt-4 mb-4">
        <a href="keluar.php" class="btn btn-primary">Logout</a>
      </div>

    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-lg fixed-top">
      <div class="container">
        <a class="navbar-brand" style="font-size: large;" href="#">Komunitas Kucing</a>
        <div class="collapse navbar-collapse text-left" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto position-absolute text-left">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Daftar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="design.php">Design</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
    crossorigin="anonymous"></script>
</body>

</html>