<?php

$konektod = mysqli_connect("localhost", "root", "", "catin023");

if (!$konektod) {
    die("Gabisa masuk rek: " . mysqli_connect_error());
}

?>