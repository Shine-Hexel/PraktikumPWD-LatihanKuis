<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Welkam-To-Home-gweh</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

  <link rel="stylesheet" href="josjis.css">

</head>

<body>
  <div class="container-fluid banner">
    <div class="container">
      <h1 style="color: #000000; font-family: arial black; padding: 20px 0;">Selamat Datang di Komunitas Kucing rekk
      </h1>
      <div class="row d-flex align-items-center">
        <div class="col-md-5">

          <img style="border: 10px solid rgb(40, 40, 40); border-radius: 10px;" id="cukurukuk" src="gambar/cukurukuk.png"
            alt="Gambar Kucing" class="img-fluid">
          <br>
          <br>

        </div>

        <div class="col-md-5">
          <p style="color: red; font-family: Arial;">Kucing adalah hewan mamalia kecil yang dikenal
            dengan sifatnya yang lincah, anggun, dan penuh rasa ingin tahu. Tubuhnya lentur dengan bulu lembut yang
            beragam warna, serta mata tajam yang mampu melihat jelas di kondisi minim cahaya. Kucing termasuk hewan
            karnivora, namun dapat beradaptasi hidup bersama manusia sebagai hewan peliharaan. Mereka memiliki kebiasaan
            mencakar untuk menandai wilayah, merawat diri dengan menjilat bulunya, serta tidur dalam waktu lama, bisa
            mencapai 12-16 jam per hari. Kucing sering dianggap pembawa kenyamanan dan kasih sayang, sehingga menjadi
            salah satu hewan peliharaan paling populer di dunia.</p>
          <br>
          <p style="color: blue; font-family: Arial;">Kucing serperti anjing termasuk hewan yang
            penyayang. Riset yang dilakukan scientificamerican mengungkapkan kucing mempelajari sendiri cara
            mengeluarkan
            bunyi meow yang bisa menarik perhatian manusia. Berikut Macam-macam kucing:</p>
          <br>
          <h2 style="color: black; font-family: Arial;">Jenis-Jenis Kucing:</h2>
          <ul style="color: purple; font-family: Arial;">
            <li>Kucing Garong</li>
            <li>Kucing Mainan</li>
            <li>Kucing Tuan Muda</li>
            <li>Kucing Nakal</li>
            <li>dll.</li>
          </ul>
        </div>

      </div>
      <a href="https://wolipop.detik.com/home/d-5180681/15-jenis-kucing-peliharaan-yang-populer-menggemaskan-dan-mudah-dirawat"
        class="btn btn-primary">Informasi Lebih Lanjut</a>
    </div>


    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-lg fixed-top">
      <div class="container">
        <a class="navbar-brand" style="font-size: large;" href="#">Komunitas Kucing</a>
        <div class="collapse navbar-collapse text-left" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto position-absolute text-left">
            <li class="nav-item">
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Daftar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="design.php">Design</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
    crossorigin="anonymous"></script>
</body>

</html>