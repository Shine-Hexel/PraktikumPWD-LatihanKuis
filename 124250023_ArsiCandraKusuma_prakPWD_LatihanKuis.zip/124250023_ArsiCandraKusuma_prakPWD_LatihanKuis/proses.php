<?php

session_start();
include 'konek.php';

$namaGweh = $_POST['namaGweh'];
$tglLahir = $_POST['tglLahir'];
$kelompokUmur = $_POST['kelompokUmur'];
$jenisKelamin = $_POST['jenisKelamin'];
$hobi = isset($_POST['hobi']) ? implode(", ", $_POST['hobi']) : '';
$asalUsul = $_POST['asalUsul'];
$kenapeLuJoin = $_POST['kenapeLuJoin'];

$query = "INSERT INTO anggota VALUES (NULL, '$namaGweh', '$tglLahir', '$kelompokUmur', '$jenisKelamin', '$hobi', '$asalUsul', '$kenapeLuJoin');";
mysqli_query($konektod, $query);

$_SESSION['login'] = true;
header("Location: design.php");
?>