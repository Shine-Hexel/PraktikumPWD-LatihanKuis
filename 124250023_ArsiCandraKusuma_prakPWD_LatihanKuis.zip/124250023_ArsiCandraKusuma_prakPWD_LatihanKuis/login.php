<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bootstrap demo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  <link rel="stylesheet" href="josjis.css">
</head>

<body>

  <div class="container-fluid banner">
    <div id="formContainer" class="container mt-4">
      <h1 style="color: #000000; font-family: arial black; padding: 20px 0; text-align: center;">Pendaftaran Komunitas
        Kucing</h1>
      <form action="proses.php" method="POST">
        <table class="table table-bordered" style="background-color: #f8f9fa; border-radius: 10px; padding: 20px;">
          <tr>
            <td>Nama Lengkap</td>
            <td><input type="text" name="namaGweh" class="form-control" required></td>
          </tr>
          <tr>
            <td>Tanggal Lahir</td>
            <td><input type="date" name="tglLahir" class="form-control" required></td>
          </tr>
          <tr>
            <td>Kelompok Umur</td>
            <td>
              <select name="kelompokUmur" class="form-control" aria-label="Pilih Kelompok Umur" required>
                <option value="" disabled selected>Pilih Kelompok Umur</option>
                <option>Anak-anak</option>
                <option>Remaja</option>
                <option>Dewasa</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>Jenis Kelamin</td>
            <td>
              <input type="radio" name="jenisKelamin" value="Laki-laki" required>Laki-laki
              <input type="radio" name="jenisKelamin" value="Perempuan" required>Perempuan
            </td>
          </tr>
          <tr>
            <td>Hobi</td>
            <td>
              <input type="checkbox" name="hobi[]" value="Nyawit"> Nyawit
              <input type="checkbox" name="hobi[]" value="Ragebait"> Ragebait
              <input type="checkbox" name="hobi[]" value="More"> Apapun selain tidur
            </td>
          </tr>
          <tr>
            <td>Asal Daerah</td>
            <td> <input type="text" name="asalUsul" class="form-control" required></td>
          </tr>
          <tr>
            <td>Alasan Ingin Bergabung</td>
            <td><textarea name="kenapeLuJoin" class="form-control" required></textarea></td>
          </tr>
        </table>
        <div class="text-center">
          <button type="submit" class="btn btn-success">KIRIM PENDAFTARAN</button>
        </div>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
    crossorigin="anonymous"></script>

</body>

</html>